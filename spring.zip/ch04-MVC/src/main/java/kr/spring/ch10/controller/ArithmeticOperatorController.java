package kr.spring.ch10.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ArithmeticOperatorController {

	@RequestMapping("/math/add.do")
																				//request�� �ڵ����� ����
	public String add(@RequestParam("op1")int op1, @RequestParam("op2")int op2, Model model){
		
		model.addAttribute("result", op1 + op2); //model ����
		
		return "math/result"; //view ����
	}
	
	@RequestMapping("/math/divide.do")
	public String divide(@RequestParam("op1")int op1, @RequestParam("op2")int op2, Model model){
		
		model.addAttribute("result", op1 / op2);
		
		return "math/result";
	}
	
}
