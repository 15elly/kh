package kr.spring.ch08.service;

import kr.spring.ch08.model.LoginCommand;

public interface AuthCheckService {

	public void authenticate(LoginCommand loginCommand) throws AuthCheckException;
	
}
