package kr.spring.ch08.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import kr.spring.ch08.model.LoginCommand;

public class LoginCommandValidator implements Validator{

	@Override
	public boolean supports(Class<?> clazz) {
		
		return LoginCommand.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
												//errors��ü, field, error message
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userId", "required");
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "required");
		
		
	}

}
