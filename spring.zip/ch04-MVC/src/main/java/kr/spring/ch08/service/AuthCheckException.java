package kr.spring.ch08.service;

public class AuthCheckException extends Exception{
	
}
