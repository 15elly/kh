package kr.spring.ch06.service;

import kr.spring.ch06.model.SearchCommand;

public class SearchService {

	public String search(SearchCommand command){
		return "�˻� �Ϸ�!";
	}
}
