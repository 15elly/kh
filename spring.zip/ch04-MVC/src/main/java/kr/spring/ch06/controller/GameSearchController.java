package kr.spring.ch06.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import kr.spring.ch06.model.SearchCommand;
import kr.spring.ch06.model.SearchType;
import kr.spring.ch06.service.SearchService;

@Controller
public class GameSearchController {
	
	@Autowired
	private SearchService searchService;
	
	//view�� ������ data ����
	@ModelAttribute("searchTypeList") //class�� ȣ��� �� ���� ����ȴ� -> request�� �����
	public List<SearchType> referenceSearchTypeList(){
		
		List<SearchType> options = new ArrayList<SearchType>();
		options.add(new SearchType(1, "��ü"));
		options.add(new SearchType(2, "�Ƶ���"));
		options.add(new SearchType(3, "���ο�"));
		
		return options;
	}

	@RequestMapping("/search/main.do")
	public String main(){
		
		return "search/main";
	}
	
	@RequestMapping("search/game.do")
	public ModelAndView search(@ModelAttribute("command")SearchCommand command){
		
		System.out.println("�˻��� : " + command.getQuery());
		
		String result = searchService.search(command);
		
		ModelAndView mav = new ModelAndView("search/game");
		
		mav.addObject("searchResult", result);
		
		return mav;
	}
}
