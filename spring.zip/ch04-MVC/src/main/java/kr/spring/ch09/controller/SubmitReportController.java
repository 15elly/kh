package kr.spring.ch09.controller;

import java.io.File;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.spring.ch09.model.SubmitReportCommand;
import kr.spring.ch09.validator.SubmitReportValidator;

@Controller
@RequestMapping("/report/submitReport.do")
public class SubmitReportController {

	String path = "E:/javaWork/workspace/ch04-MVC/src/main/webapp/upload";
	
	//Ŀ�ǵ� ��ü(java bean) �ʱ�ȭ
	@ModelAttribute("report")
	public SubmitReportCommand initCommand(){
		return new SubmitReportCommand();
	}
	
	@RequestMapping(method=RequestMethod.GET)
	public String form(){
		
		return "report/submitReportForm";
	}
	
	@RequestMapping(method=RequestMethod.POST)
	public String submit(@ModelAttribute("report")SubmitReportCommand command, BindingResult result){
		
		//���Ἲ üũ
		new SubmitReportValidator().validate(command, result);
		
		if(result.hasErrors()){
			return form();
		}
		
		if(!command.getReportFile().isEmpty()){
			
			try{
				//���۵� ������ ���ϴ� ��ο� ����
				File file = new File(path + "/" + command.getReportFile().getOriginalFilename());
				command.getReportFile().transferTo(file); // transferTo() : file ������ ��η� �Ű��ִ� ����
				
				System.out.println("���� : " + command.getSubject());
				System.out.println("���ε�� ���� : " + command.getReportFile().getOriginalFilename());
				System.out.println("���ε��� ���� �뷮 : " + command.getReportFile().getSize() + "byte");
				
			}catch(Exception e){
				e.printStackTrace();
			}
			
		}
		
		return "report/submittedReport";
	}
	
}
