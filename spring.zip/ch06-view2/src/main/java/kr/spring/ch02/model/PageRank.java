package kr.spring.ch02.model;

public class PageRank {

}
