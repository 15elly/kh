package kr.spring.ch02.controller;

public class PageRanksController {

}
