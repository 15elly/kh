package kr.spring.ch06;

import org.springframework.stereotype.Component;

//@Component를 지정한 class는 자동 스캔 대상이 된다. (명시하지 않았을 시 자동 스캔이 되지 않음)
@Component 
public class Camera {

}
