package kr.spring.ch02;

import org.springframework.beans.factory.annotation.Autowired;

public class SystemMonitor {

	private int periodTime;
	private SmsSender sender;
	
	public int getPeriodTime() {
		return periodTime;
	}
	public void setPeriodTime(int periodTime) {
		this.periodTime = periodTime;
	}
	public SmsSender getSender() {
		return sender;
	}
	
	/*
	 * 생성자, 필드(멤버변수), 메서드에 지정 가능
	 * 메서드에 지정할 때는 setXXXX뿐만 아니라 일반 메서드에도 적용 가능
	 * 
	 * @Autowired annotation은 Type을 이용해서 자동적으로 property값을 설정하기 때문에
	 * 해당 Type의 Bean 객체가 존재하지 않거나 Bean 객체가 2개 이상 존재할 경우, 
	 * spring은 @Autowired annotation이 적용된 Bean 객체를 생성할 때 예외를 발생시킴
	 * 
	 * @Autowired(required=false)로 지정하면 해당 Type의 Bean 객체가 존재하지 않더라고
	 * spring은 예외를 발생시키지 않는다.
	 * 기본값 : @Autowired(required=true)
	 */
	@Autowired
	public void setSender(SmsSender sender) {
		this.sender = sender;
	}
	
}
