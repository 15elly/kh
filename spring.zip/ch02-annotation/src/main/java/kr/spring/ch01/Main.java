package kr.spring.ch01;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static void main(String[] args) {
		
		String[] configLocations = new String[]{"applicationContext.xml"};
		
		AbstractApplicationContext context = new ClassPathXmlApplicationContext(configLocations);
		
		//@Required annotation을 이용한 필수 property 설정
		Camera camera = (Camera)context.getBean("camera1");
		System.out.println(camera);
		
		//어플리케이션 종료시 컨테이너에 존재하는 모든 빈(객체)를 종료
		context.close();
	}
}