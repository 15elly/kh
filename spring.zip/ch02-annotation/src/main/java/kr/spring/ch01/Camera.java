package kr.spring.ch01;

import org.springframework.beans.factory.annotation.Required;

public class Camera {

	private int number;
	
	//@Required 어노테이션을 이용한 필수 property 검사
	//method에만 표시 가능, property에 표시 불가능
	@Required
	public void setNumber(int number) {
		this.number = number;
	}

	@Override
	public String toString() {
		return "Camera [number=" + number + "]";
	}
}
