package kr.spring.ch07;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;

//자바 코드 기반 설정
@Configuration
public class SpringConfig {

	/*
	 * ScopedProxyMode.NO - 프록시를 적용하지 않는다.
	 * ScopedProxyMode.INTERFACES - 인터페이스에 대해 프록시를 생성한다.
	 * ScopedProxyMode.TARGET_CALSS - 클래스에 대해 프록시를 생성한다.
	 * ScopedProxyMode.DEFAULT - 기본 설정을 사용
	 */
	
	@Bean
	@Scope(value="prototype",proxyMode=ScopedProxyMode.TARGET_CLASS)
	public Worker worker(){
		return new Worker();
	}
	
	@Bean
	public Executor executor(){
		Executor executor = new Executor();
		executor.setWorker(worker());
		
		return executor;
	}
}
