package kr.spring.ch07;

public class Worker {

	public void work(WorkUnit unit){
		System.out.println(toString() + ", work " + unit);
	}
}
