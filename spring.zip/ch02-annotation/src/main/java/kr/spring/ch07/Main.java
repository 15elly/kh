package kr.spring.ch07;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {
	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
		
		//자바코드 기반 설정
		Executor executor = (Executor)context.getBean("executor");
		executor.addUnit(new WorkUnit());
		executor.addUnit(new WorkUnit()); //Work는 컨테이너에 들어가있기 때문에 싱글톤으로 호출됨
		
	}
}
