package kr.spring.ch03;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class SystemMonitor2 {
	
	//@Autowired를 멤버필드에 명시하면 setXXXXXX method를 생략할 수 있다.
	@Autowired
	@Qualifier("main")
	private Recorder recorder;

	public Recorder getRecorder() {
		return recorder;
	}

	/*public void setRecorder(Recorder recorder) {
		this.recorder = recorder;
	}*/
	
	
}
