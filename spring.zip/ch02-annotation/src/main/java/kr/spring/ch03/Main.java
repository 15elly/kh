package kr.spring.ch03;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static void main(String[] args) {
		
		String[] configLocations = new String[]{"applicationContext.xml"};
		
		AbstractApplicationContext context = new ClassPathXmlApplicationContext(configLocations);
		
		//@Qualifier annotation을 이용한 자동 설정 제한
		SystemMonitor2 monitor = (SystemMonitor2)context.getBean("systemMonitor");
		System.out.println(monitor.getRecorder());
		
		//어플리케이션 종료시 컨테이너에 존재하는 모든 빈(객체)를 종료
		context.close();
	}
}