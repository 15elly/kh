package kr.spring.ch04;

import javax.annotation.Resource;

public class HomeController {

					//자동으로 설정할 Bean 객체의 이름
	@Resource(name="camera2") //jdk 6.0이상부터 지원, field에 명시할 시 setXXXXX method 생략 가능
	private Camera camera2;
	
	@Resource(name="camera3")
	private Camera camera3;
	
	private Camera camera4;

	//@Resource annotation을 멤버 필드에 설정하면 setXXXXX method 생략 가능
	@Resource(name="camera4")
	public void setCamera4(Camera camera4) {
		this.camera4 = camera4;
	}

	@Override
	public String toString() {
		return "HomeController [camera2=" + camera2 + ", camera3=" + camera3 + ", camera4=" + camera4 + "]";
	}
	
}
