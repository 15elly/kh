package kr.spring.ch04;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static void main(String[] args) {
		
		String[] configLocations = new String[]{"applicationContext.xml"};
		
		AbstractApplicationContext context = new ClassPathXmlApplicationContext(configLocations);
		
		//@Resource annotation을 이용한 property 설정
		HomeController home = (HomeController)context.getBean("homeController");
		System.out.println(home);
		
		//어플리케이션 종료시 컨테이너에 존재하는 모든 빈(객체)를 종료
		context.close();
	}
}