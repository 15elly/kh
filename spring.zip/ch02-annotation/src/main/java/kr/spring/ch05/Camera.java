package kr.spring.ch05;

public class Camera {

}
