package kr.spring.ch05;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;

public class HomeController2 {

	private Camera camera;

	@Resource(name="camera5")
	public void setCamera(Camera camera) {
		this.camera = camera;
	}

	public Camera getCamera() {
		return camera;
	}

	@PostConstruct
	public void init(){
		System.out.println("init() method 동작");
	}
	
	@PreDestroy
	public void close(){
		System.out.println("close() method 동작");
	}
}
