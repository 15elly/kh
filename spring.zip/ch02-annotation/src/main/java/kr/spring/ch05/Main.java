package kr.spring.ch05;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static void main(String[] args) {
		
		String[] configLocations = new String[]{"applicationContext.xml"};
		
		AbstractApplicationContext context = new ClassPathXmlApplicationContext(configLocations);
		
		//@PostConstruct, @PreDestroy annotation을 이용한 life cycle
		HomeController2 home = (HomeController2)context.getBean("homeController2");
		System.out.println(home);
		
		//어플리케이션 종료시 컨테이너에 존재하는 모든 빈(객체)를 종료
		context.close();
	}
}