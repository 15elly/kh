package kr.spring.ch01.service;

public interface AuthCheckService {

	public void authenticate(String id, String password) throws AuthCheckException;
	
}
