package kr.spring.ch01.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.spring.ch01.model.LoginCommand;
import kr.spring.ch01.service.AuthCheckException;
import kr.spring.ch01.service.AuthCheckService;
import kr.spring.ch01.validator.LoginCommandValidator;

@Controller
public class LoginController {
	
	@Autowired
	private AuthCheckService authCheckService;
	
	//Ŀ�ǵ� ��ü(java bean) �ʱ�ȭ
	@ModelAttribute("login")
	public LoginCommand initCommand(){
		return new LoginCommand();
	}

	@RequestMapping(value="/login/login.do", method=RequestMethod.GET)
	public String form(){
		
		return "login/loginForm";
	}
	
	@RequestMapping(value="/login/login.do", method=RequestMethod.POST)
	public String submit(@ModelAttribute("login")LoginCommand loginCommand, BindingResult result){
		
		//��ȿ�� üũ
		new LoginCommandValidator().validate(loginCommand, result);
		
		//���Ἲ üũ ��� ������ ������ form ȣ��
		if(result.hasErrors()){
			return form();
		}
		
		//�α��� üũ
		try{
			
			authCheckService.authenticate(loginCommand.getId(), loginCommand.getPassword());
			
			return "login/loginSuccess";
			
		}catch(AuthCheckException e){
			//�α��� ����
			result.reject("invalidIdOrPassword", new Object[]{loginCommand.getId()}, null);
			return form();
		}
		
		
	}
	
}
