package kr.spring.ch01.service;

public class AuthCheckException extends Exception{

	public AuthCheckException(String message) {
		super(message);
	}
}
