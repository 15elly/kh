package kr.spring.ch01.service;

public class AuthCheckServiceImpl implements AuthCheckService{

	@Override
	public void authenticate(String id, String password) throws AuthCheckException {
		
		if(!id.equals("dragon")){
			System.out.println("�α��� ����");
			throw new AuthCheckException("invalid id : " + id);
		}
		
	}

}
