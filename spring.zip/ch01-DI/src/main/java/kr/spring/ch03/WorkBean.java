package kr.spring.ch03;

public class WorkBean {
	public String work(String name){
		return name+"님이 열심히 일합니다.";
	}
}
