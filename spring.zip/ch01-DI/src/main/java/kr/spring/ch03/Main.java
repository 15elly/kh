package kr.spring.ch03;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static void main(String[] args) {
		//설정파일
		String[] configLocations = new String[]{"applicationContext.xml"};
		
		//설정 파일을 읽어들여 spring container를 생성
		AbstractApplicationContext context = new ClassPathXmlApplicationContext(configLocations);
		
		//객체를 container로부터 일어들임
		WorkBean workBean = (WorkBean)context.getBean("workBean");
		String message = workBean.work("장영실");
		
		System.out.println(message);
		
		//application 종료 시, container에 존재하는 모든 bean(객체)를 종료
		context.close();
		
	}
}
