package kr.spring.ch10;

public class SmsSender {

	@Override
	public String toString() {
		return "SmsSender 호출";
	}

}
