package kr.spring.ch10;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static void main(String[] args) {
		//설정파일
		String[] configLocations = new String[]{"applicationContext.xml"};
		
		//설정 파일을 읽어들여 spring container를 생성
		AbstractApplicationContext context = new ClassPathXmlApplicationContext(configLocations);
		
		//임의의 bean 객체 전달
		SystemMonitor monitor = (SystemMonitor)context.getBean("monitor3");
		System.out.println(monitor);
		
		//application 종료 시, container에 존재하는 모든 bean(객체)를 종료
		context.close();

	}
}
