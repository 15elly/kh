package kr.spring.ch17;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static void main(String[] args) {
		//설정파일
		String[] configLocations = new String[]{"applicationContext2.xml"};
		
		//설정 파일을 읽어들여 spring container를 생성
		AbstractApplicationContext context = new ClassPathXmlApplicationContext(configLocations);
		
		//부모 bean을 통한 설정 재사용
		SystemMonitor monitor = (SystemMonitor)context.getBean("doorMonitor");
		System.out.println(monitor);
		
		SystemMonitor monitor2 = (SystemMonitor)context.getBean("lobbyMonitor");
		System.out.println(monitor2);
		
		SystemMonitor monitor3 = (SystemMonitor)context.getBean("roomMonitor");
		System.out.println(monitor3);
		
		//application 종료 시, container에 존재하는 모든 bean(객체)를 종료
		context.close();

	}
}

