package kr.spring.ch17;

public class SmsSender {

}
