package kr.spring.ch11;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static void main(String[] args) {
		//설정파일
		String[] configLocations = new String[]{"applicationContext.xml"};
		
		//설정 파일을 읽어들여 spring container를 생성
		AbstractApplicationContext context = new ClassPathXmlApplicationContext(configLocations);
		
		//List 타입 프로퍼티 설정
		PerfomanceMonitor monitor = (PerfomanceMonitor)context.getBean("performanceMonitor");
		System.out.println(monitor);
		
		//application 종료 시, container에 존재하는 모든 bean(객체)를 종료
		context.close();

	}
}
