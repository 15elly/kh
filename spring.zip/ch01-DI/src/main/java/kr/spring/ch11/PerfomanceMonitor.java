package kr.spring.ch11;

import java.util.List;

public class PerfomanceMonitor {
	private List<Double> devitions;

	public void setDevitions(List<Double> devitions) {
		this.devitions = devitions;
	}

	@Override
	public String toString() {
		return "PerfomanceMonitor [devitions=" + devitions + "]";
	}
}
