package kr.spring.ch18;

public class Worker {

}