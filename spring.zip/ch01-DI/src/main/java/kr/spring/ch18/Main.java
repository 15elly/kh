package kr.spring.ch18;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
   public static void main(String[] args) {
      
      String[] configLocations = new String[]{"applicationContext2.xml"};
      
      AbstractApplicationContext context = new ClassPathXmlApplicationContext(configLocations);
      
      //서로 다른 범위의 빈에 대한 의존 처리
      Executor executor = (Executor)context.getBean("executor");
      System.out.println(executor);
      
      Executor executor2 = (Executor)context.getBean("executor");
      System.out.println(executor2);
      
      System.out.println("-------------------------------------------");
      
      //호출할 때마다 새로운 객체를 생성해 주소를 반환한다 -> prototype
      Executor executor3 = (Executor)context.getBean("executor");
      System.out.println(executor3 + ", " + executor3.getWorker());
      
      Executor executor4 = (Executor)context.getBean("executor");
      System.out.println(executor4 + ", " + executor4.getWorker());
            
      //어플리케이션 종료시 컨테이너에 존재하는 모든 빈(객체)를 종료
      context.close();
   }
}