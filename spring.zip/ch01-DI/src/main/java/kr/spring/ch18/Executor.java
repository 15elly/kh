package kr.spring.ch18;

public class Executor {

   private Worker worker;

   public Worker getWorker() {
      return worker;
   }

   public void setWorker(Worker worker) {
      this.worker = worker;
   }   
}