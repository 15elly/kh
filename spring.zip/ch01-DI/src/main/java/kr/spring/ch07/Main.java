package kr.spring.ch07;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static void main(String[] args) {
		//설정파일
		String[] configLocations = new String[]{"applicationContext.xml"};
		
		//설정 파일을 읽어들여 spring container를 생성
		AbstractApplicationContext context = new ClassPathXmlApplicationContext(configLocations);
		
		//DI(Dependency Injection) 프로퍼티 설정 방식(XML 네임스페이스 이용)으로 생성된 객체를 container에서 읽어옴
		SystemMonitor monitor = (SystemMonitor)context.getBean("monitor2");
		System.out.println(monitor);
				
		//application 종료 시, container에 존재하는 모든 bean(객체)를 종료
		context.close();

	}
}
