package kr.spring.ch07;

public class SmsSender {

	@Override
	public String toString() {
		return "SmsSender 호출";
	}

}
