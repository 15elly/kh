package kr.spring.ch16;

public class PhoneCall {
	private PhoneCall call;

	public void setCall(PhoneCall call) {
		this.call = call;
	}

	@Override
	public String toString() {
		return "PhoneCall [call=" + call + "]";
	}
	
	
}
