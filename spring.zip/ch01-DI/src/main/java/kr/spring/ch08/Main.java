package kr.spring.ch08;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static void main(String[] args) {
		//설정파일
		String[] configLocations = new String[]{"applicationContext.xml"};
		
		//설정 파일을 읽어들여 spring container를 생성
		AbstractApplicationContext context = new ClassPathXmlApplicationContext(configLocations);
		
		//싱글톤 패턴
		ParserFactory parser = (ParserFactory)context.getBean("parser");
		System.out.println(parser);
		
		ParserFactory parser2 = (ParserFactory)context.getBean("parser");
		System.out.println(parser2);

		
		//application 종료 시, container에 존재하는 모든 bean(객체)를 종료
		context.close();

	}
}
