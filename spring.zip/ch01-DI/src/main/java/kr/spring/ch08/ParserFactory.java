package kr.spring.ch08;

public class ParserFactory {
	//싱글톤 패턴
	private static ParserFactory instance = new ParserFactory();
	
	public static ParserFactory getInstance(){
		return instance;
	}
	
	private ParserFactory(){} //생성자를 막아줌
	
	@Override
	public String toString() {
		return super.toString() + ", ParserFactory 호출";
	}
}
