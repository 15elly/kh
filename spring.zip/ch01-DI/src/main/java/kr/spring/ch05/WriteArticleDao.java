package kr.spring.ch05;

public class WriteArticleDao {
   public void insert(){
      System.out.println("WriteArticleDao의 insert()메서드 실행");
   }
}