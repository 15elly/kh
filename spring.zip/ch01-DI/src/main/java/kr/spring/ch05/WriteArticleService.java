package kr.spring.ch05;

public class WriteArticleService {
   private WriteArticleDao writeArticleDao;
   
   //의존 관계 설정 방식 : property방식
   public void setWriteArticleDao(WriteArticleDao writeArticleDao){
      this.writeArticleDao = writeArticleDao;
   }
   
   public void write(){
      System.out.println("WriteArticleService의 write()메서드 실행");
      
      writeArticleDao.insert();
   }
}