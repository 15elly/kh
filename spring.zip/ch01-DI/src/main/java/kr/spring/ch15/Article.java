package kr.spring.ch15;

public class Article {

}
