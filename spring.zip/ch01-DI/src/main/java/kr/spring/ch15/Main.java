package kr.spring.ch15;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static void main(String[] args) {
		//설정파일
		String[] configLocations = new String[]{"applicationContext2.xml"};
		
		//설정 파일을 읽어들여 spring container를 생성
		AbstractApplicationContext context = new ClassPathXmlApplicationContext(configLocations);
		
		/*
		 * bean 객체의 타입이나 이름을 이용하여 의존 객체를 자동으로 설정할 수 있는 기능
		 * byName : 프로퍼티의 이름과 같은 이름을 갖는 bean 객체를 설정
		 * byType : 프로퍼티의 타입과 같은 타입을 갖는 bean 객체를 설정
		 * constructor : 생성자 파라미터 타입과 같은 타입을 갖는 bean 객체를 생성자에 전달 
		 */
		
		//프로퍼티 이름을 이용한 의존 관계 자동 설정
		WriteArticleService articleService = (WriteArticleService)context.getBean("writeArticleService");
		articleService.write(new Article());
		
		//application 종료 시, container에 존재하는 모든 bean(객체)를 종료
		context.close();

	}
}

