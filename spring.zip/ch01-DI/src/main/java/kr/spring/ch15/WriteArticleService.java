package kr.spring.ch15;

public interface WriteArticleService {
	void write(Article article);
}
