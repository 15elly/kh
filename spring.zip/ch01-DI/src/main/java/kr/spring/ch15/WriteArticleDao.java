package kr.spring.ch15;

public class WriteArticleDao implements ArticleDao{

	@Override
	public void insert(Article article) {
		System.out.println("WriteArticleDao의 insert() 호출");
	}

}
