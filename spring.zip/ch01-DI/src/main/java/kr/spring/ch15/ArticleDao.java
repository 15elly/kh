package kr.spring.ch15;

public interface ArticleDao {
	void insert(Article article);
}
