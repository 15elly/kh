package kr.spring.ch02;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static void main(String[] args) {
		//설정파일
		String[] configLocations = new String[]{"applicationContext.xml"};
		
		//설정파일을 읽어들여 spring container를 생성
		AbstractApplicationContext context = new ClassPathXmlApplicationContext(configLocations);
		
		//객체를 container로부터 읽어들임
									//Object형으로 down casting
		GreetingBean greetingBean = (GreetingBean)context.getBean("greetingBean");
		greetingBean.welcome("박문수");
	
		//application 종료 시, container에 존재하는 모든 bean(객체)를 종료
		context.close();
	}
}
