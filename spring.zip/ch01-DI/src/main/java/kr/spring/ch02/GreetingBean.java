package kr.spring.ch02;

public class GreetingBean {
	public void welcome(String name){
		System.out.println(name+"님 방문을 환영합니다.");
	}
}
