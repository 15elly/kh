package kr.spring.ch09;

public class SomeCommand {
	public void execute(){
		System.out.println("SomeCommand executed!");
	}
	
}
