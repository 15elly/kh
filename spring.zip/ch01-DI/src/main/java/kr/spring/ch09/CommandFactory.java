package kr.spring.ch09;

public class CommandFactory {
   public SomeCommand createCommand(String commandName){
      if(commandName.equals("some")){
         return new SomeCommand();
      }
      return null;
   }
}