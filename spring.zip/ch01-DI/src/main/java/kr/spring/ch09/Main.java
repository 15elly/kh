package kr.spring.ch09;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static void main(String[] args) {
		//설정파일
		String[] configLocations = new String[]{"applicationContext.xml"};
		
		//설정 파일을 읽어들여 spring container를 생성
		AbstractApplicationContext context = new ClassPathXmlApplicationContext(configLocations);
		
		//룩업 메서드 인젝션 방식
		Processor processor = (Processor)context.getBean("processor");
		processor.process("some");
		
		//application 종료 시, container에 존재하는 모든 bean(객체)를 종료
		context.close();

	}
}
