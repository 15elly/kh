package kr.spring.ch09;
/*
    룩업 메서드 인젝션 방식은 필요한 객체를 제공하는
    룩업(look up) 메서드를 구현하는 방식
 */
public abstract class Processor {
   public void process(String commandName){
	   //lookup 메서드 호출
	   CommandFactory factory = getCommandFactory();
	   SomeCommand command = factory.createCommand(commandName);
	   command.execute();
   }
   
   /* lookup 메서드 정의 규칙
    * - 접근 수식어가  public이나 protected이어야 함
    * - 리턴 타입이 void가 아니어야 함
    * - 인자를 갖지 않아야 함
    * - 추상메서드이어도 됨
    * - final이 아니어야 함
    */
   //추상메서드(lookup 메서드)
   protected abstract CommandFactory getCommandFactory();
}