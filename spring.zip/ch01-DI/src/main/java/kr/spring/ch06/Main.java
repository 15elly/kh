package kr.spring.ch06;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static void main(String[] args) {
		//설정파일
		String[] configLocations = new String[]{"applicationContext.xml"};
		
		//설정 파일을 읽어들여 spring container를 생성
		AbstractApplicationContext context = new ClassPathXmlApplicationContext(configLocations);
		
		//DI(Dependency Injection) 생성자 설정 방식(인자전달)으로 생성된 객체를 container에서 읽어옴
		SystemMonitor monitor = (SystemMonitor)context.getBean("monitor");
		System.out.println(monitor);
		
		//application 종료 시, container에 존재하는 모든 bean(객체)를 종료
		context.close();

	}
}
