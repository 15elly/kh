package kr.spring.ch06;

public class SmsSender {
	@Override
	public String toString(){
		return "SmsSender 호출";
	}
}
