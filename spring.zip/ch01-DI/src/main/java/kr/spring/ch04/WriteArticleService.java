package kr.spring.ch04;

public class WriteArticleService {
	private WriteArticleDao writeArticleDao;
	
	//의존 관계 설정 방식 : 생성자
	public WriteArticleService(WriteArticleDao writeArticleDao){
		this.writeArticleDao = writeArticleDao;
	}
	
	public void write(){
		System.out.println("WriteArticleService의 write()메서드 실행");
		
		writeArticleDao.insert();
	}
}
