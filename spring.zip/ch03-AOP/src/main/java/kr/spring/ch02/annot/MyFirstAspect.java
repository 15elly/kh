package kr.spring.ch02.annot;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class MyFirstAspect {
	/*
	 * 구현 가능한 Advice 종류
	 * 종류						설명
	 * Before Advice			대상 객체의 메서드 호출 전에 공통 기능을 실행
	 * @Before
	 * 
	 * After Returning Advice	대상 객체의 메서드가 예외 없이 실행한 이후에 공통 기능을 실행
	 * @AfterReturning
	 * 
	 * After Throwing Advice	대상 객체의 메서드를 실행하는 도중 예외가 발생한 경우에 공통 기능을 실행
	 * @AfterThrowing
	 * 
	 * After Advice				대상 객체의 메서드를 실행하는 도중 예외가 발생했는지의 여부와 상관없이, 메서드 실행 후 공통 기능을 실행(try~catch~finally의 finally와 같은 기능을 수행)
	 * @After
	 * 
	 * Around Advice			대상 객체의 메서드 실행 전, 후 또는 예외 발생 시점에 공통 기능을 실행하는데 사용
	 * @Around
	 */
	
	@Pointcut("execution(public String launch())")
	public void getPointcut(){}
	
	//메서드 시작 직전에 동작하는 어드바이스
	//@Before("getPointcut()")
	public void before(){
		System.out.println("Hello Before! **메서드가 호출되기 전에 나온다!");
	}
	
	//메서드 호출이 예외를 내보내지 않고 종료했을 때 동작하는 어드바이스
	//@AfterReturning(value="getPointcut()",returning="msg")
	public void afterReturning(String msg){
		System.out.println("Hello AfterReturning! **메서드가 호출한 후에 나온다! 전달된 객체 : " + msg);
	}
	
	//메서드 호출이 예외를 던졌을 때 동작하는 어드바이스
	//@AfterThrowing(value="getPointcut()",throwing="ex")
	public void afterThrowing(Throwable ex){
		System.out.println("Hello AfterThrowing! **예외가 생기면 나온다! 예외 : " + ex);
	}
	
	//예외가 발생해도 실행됨
	//메서드 종료 후에 동작하는 어드바이스
	//@After("getPointcut()")
	public void after(){
		System.out.println("Hello After! **메서드가 호출된 후에 나온다!");
	}
	
	//메서드 호출 전후에 동작하는 어드바이스
	@Around("getPointcut()")
	public String around(ProceedingJoinPoint joinPoint) throws Throwable{
		System.out.println("Hello Around before! **메서드가 호출되기 전에 나온다!");
		String s = null;
		
		//try~catch~finally 구조로 명시해야, 예외가 발생해도 메서드 실행 후, 공통 기능을 수행한다.
		try {
			//메서드 실행 후, 반환되는 객체
			s = (String)joinPoint.proceed(); //핵심 기능 호출
		}catch (Exception e) {

		}finally {
			System.out.println("Hello Around after! **메서드가 호출된 후에 나온다! 반환된 객체 : " + s);
		}
		return s;
	}
}
