package kr.spring.ch02.annot;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import kr.spring.product.Product;

public class Main {
	public static void main(String[] args) {
		String[] configLocations = new String[]{"applicationContextAnnot.xml"};
		AbstractApplicationContext context = new ClassPathXmlApplicationContext(configLocations);
		
		Product p = (Product)context.getBean("product");
		p.launch();
		
		context.close();
		
	}
}
